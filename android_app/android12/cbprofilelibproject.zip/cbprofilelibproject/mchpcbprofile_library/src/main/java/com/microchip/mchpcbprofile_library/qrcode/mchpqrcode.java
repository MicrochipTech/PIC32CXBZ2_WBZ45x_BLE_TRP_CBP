package com.microchip.mchpcbprofile_library.qrcode;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.microchip.mchpcbprofile_library.qrcode.qrcode.mchpqrcode_Callback;

public class mchpqrcode {
    private Context ACTIVITY;
    private mchpqrcode_Callback CALLBACK;
    public final static String QRCODE_RESULT             = "com.microchip.mchpcbprofile_library.qrcode.QRCODE_RESULT";
    public final static String QRCODE_STRING             = "com.microchip.mchpcbprofile_library.qrcode.QRCODE_STRING";

    public mchpqrcode(Context activity){
        ACTIVITY = activity;
    }

    private IntentFilter constructQRCIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(QRCODE_RESULT);
        return intentFilter;
    }

    private final BroadcastReceiver BcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (QRCODE_RESULT.equals(action)) {
                String s = intent.getStringExtra(QRCODE_STRING);
                ACTIVITY.unregisterReceiver(BcastReceiver);
                CALLBACK.QRCOdeString(s);
            }
        }
    };

    public void GetQRCode(mchpqrcode_Callback cb)
    {
        CALLBACK = cb;
        Intent myIntent = new Intent(ACTIVITY, qrcodeActivity.class);
        ACTIVITY.startActivity(myIntent);
        ACTIVITY.registerReceiver(BcastReceiver,constructQRCIntentFilter());
    }



}
