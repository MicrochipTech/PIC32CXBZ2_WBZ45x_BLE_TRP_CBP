package com.microchip.mchpcbprofile_library.ble;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public class BLE_Permissions extends Activity {
    private static final int REQ_CODE_BLUETOOTH12       = 2;
    private static final int REQ_CODE_ACCESS_LOCATION   = 3;
    public final static String ACTION_BLE_PERMISSION_GRANTED = "com.microchip.ACTION_BLE_PERMISSION_GRANTED";
    public final static String ACTION_BLE_PERMISSION_DENIED  = "com.microchip.ACTION_BLE_PERMISSION_DENIED";
    private boolean [] grants = new boolean[]{false,false};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if ((this.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                    || (this.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_CODE_BLUETOOTH12);
                Log.d("BLECB","... request for bluetooth permissions sent.");
            }else{
                sendBroadcast(new Intent(ACTION_BLE_PERMISSION_GRANTED));
                finish();
            }
        }else{
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_CODE_ACCESS_LOCATION);
            Log.d("BLECB","... request for location permissions sent.");
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQ_CODE_ACCESS_LOCATION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("BLECB","Location permission granted");
                    grants[0] = true;
                    if(grants[0] && grants[1])
                    {
                        sendBroadcast(new Intent(ACTION_BLE_PERMISSION_GRANTED));
                        finish();
                    }
                }
                break;
            case REQ_CODE_BLUETOOTH12:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("BLECB","Bluetooth permission granted");
                    grants[1] = true;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_CODE_ACCESS_LOCATION);
                } else {
                    Log.d("BLECB","Bluetooth permission denied");
                    sendBroadcast(new Intent(ACTION_BLE_PERMISSION_DENIED));
                    finish();
                }
                break;
        }
    }

    @Override
    public void onStop(){
        super.onStop();
    }
    /*private static final int REQ_CODE_ACCESS_LOC1 = 3;
    private static final int REQ_CODE_ACCESS_LOC2 = 4;
    public final static String ACTION_BLE_PERMISSION_GRANTED = "com.microchip.ACTION_BLE_PERMISSION_GRANTED";
    public final static String ACTION_BLE_PERMISSION_DENIED  = "com.microchip.ACTION_BLE_PERMISSION_DENIED";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_CODE_ACCESS_LOC1);
        }
    }

    private void showLocationPermissionDialog(final Runnable callback) {
        AlertDialog dialog;
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(this);
        dialog = builder.create();
        dialog.dismiss();
        builder.setTitle("Location Permission Required");
        builder.setMessage("App cannot scan");
        builder.setPositiveButton("continue", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                callback.run();
            }
        });
        builder.setNegativeButton(null, null);
        dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQ_CODE_ACCESS_LOC1:
                if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                    showLocationPermissionDialog(new Runnable() {
                        @TargetApi(Build.VERSION_CODES.M)
                        @Override
                        public void run() {
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_CODE_ACCESS_LOC2);
                        }
                    });
                }
            case REQ_CODE_ACCESS_LOC2:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //simpleMAP_debug.getInstance().print("Coarse location permission granted");
                    sendBroadcast(new Intent(ACTION_BLE_PERMISSION_GRANTED));
                    finish();
                }else{
                    //simpleMAP_debug.getInstance().printAlways("Coarse location permission denied");
                    sendBroadcast(new Intent(ACTION_BLE_PERMISSION_DENIED));
                    finish();
                }
        }
    }

    @Override
    public void onStop(){
        super.onStop();
    }*/
}