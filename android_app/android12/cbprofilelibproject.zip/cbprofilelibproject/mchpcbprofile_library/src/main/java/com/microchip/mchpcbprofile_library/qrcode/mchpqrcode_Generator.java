package com.microchip.mchpcbprofile_library.qrcode;

import android.graphics.Bitmap;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.util.HashMap;
import java.util.Map;

public class mchpqrcode_Generator {
    private ImageView targetView;

    public mchpqrcode_Generator(ImageView targetimageview){
        targetView = targetimageview;
    }

    public void generate(String qrcodecontent){
        int mWidth=300, mHeight=300;
        Map<EncodeHintType, Object> hintsMap = new HashMap<>();
        hintsMap.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hintsMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
        hintsMap.put(EncodeHintType.MARGIN, 0);
        try {
            BitMatrix bitMatrix = new QRCodeWriter().encode(qrcodecontent, BarcodeFormat.QR_CODE, mWidth, mHeight, hintsMap);
            int[] pixels = new int[mWidth * mHeight];
            for (int i = 0; i < mHeight; i++) {
                for (int j = 0; j < mWidth; j++) {
                    if (bitMatrix.get(j, i)) {
                        pixels[i * mWidth + j] = 0xFF000000;
                    } else {
                        pixels[i * mWidth + j] = 0xFFFFFFFF;//282946;
                    }
                }
            }
            targetView.setImageBitmap( Bitmap.createBitmap(pixels, mWidth, mHeight, Bitmap.Config.ARGB_8888));
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}
