package com.microchip.mchpcbprofile_library.ble;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.util.Arrays;

public class BLE_Service extends Service {
    public Activity ACTIVITY = null;
    private BluetoothAdapter mBluetoothAdapter;
    public BluetoothGatt mBluetoothGatt;
    private final IBinder mBinder = new LocalBinder();
    private static Boolean PERMISSION_REQUEST_IN_COURSE = false;
    private BLE_Scanner bleScanner = null;
    private boolean CONNECTED_STATUS = false;

    private final static String ACTION_BLE_ADAPTER_STATE_CHANGED      = "android.bluetooth.adapter.action.STATE_CHANGED";
    public final static String  ACTION_BLE_INIT_COMPLETED             = "com.microchip.ACTION_BLE_INIT_COMPLETED";
    public final static String  ACTION_BLE_INIT_FAILED                = "com.microchip.ACTION_BLE_INIT_FAILED";
    public final static String  ACTION_BLE_INIT_FAILED_REASON         = "com.microchip.ACTION_BLE_INIT_FAILED_REASON";
    public final static String  ACTION_BLE_NEW_SCAN_RESULT            = "com.microchip.ACTION_BLE_INIT_FAILED_REASON";
    public final static String  ACTION_BLE_SCAN_STRING_ARRAY          = "com.microchip.ACTION_BLE_SCAN_STRING_ARRAY";
    public final static String  ACTION_BLE_PERIPHERAL_CONNTIMEOUT     = "com.microchip.ACTION_BLE_PERIPHERAL_CONNTIMEOUT";


    /**
     *
     *      CREATE, BIND, DESTROY
     */
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        if (mBluetoothGatt != null) {
            unregisterReceiver(broadcastReceiver);
            mBluetoothGatt.close();
            mBluetoothGatt = null;
        }
        return super.onUnbind(intent);
    }
    public class LocalBinder extends Binder {
        BLE_Service getService() {
            return BLE_Service.this;
        }
    }
    @Override
    public void onCreate() {
        super.onCreate();
        registerReceiver(broadcastReceiver, intentFilter());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                PERMISSION_REQUEST_IN_COURSE = true;
                Intent startPermissionActivity =  new Intent(getApplicationContext(), BLE_Permissions.class);
                startPermissionActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(startPermissionActivity);
            } else{
                PERMISSION_REQUEST_IN_COURSE = false;
            }
        }
    }
    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(broadcastReceiver);
            if (mBluetoothGatt != null) {
                mBluetoothGatt.close();
                mBluetoothGatt = null;
            }
        }
        catch (Exception e) {
            Log.d("BLECB","EXCEPTION: "+ e);
        }
        super.onDestroy();
    }


    /**
     *          INTENT MANAGEMENT
     */
    private static IntentFilter intentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BLE_Service.ACTION_BLE_ADAPTER_STATE_CHANGED);
        intentFilter.addAction(BLE_Permissions.ACTION_BLE_PERMISSION_DENIED);
        intentFilter.addAction(BLE_Permissions.ACTION_BLE_PERMISSION_GRANTED);
        intentFilter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        intentFilter.addAction(ACTION_BLE_PERIPHERAL_CONNTIMEOUT);
        return intentFilter;
    }

    private void sendBroadcastInitFailed(String reason)
    {
        Intent myintent = new Intent(ACTION_BLE_INIT_FAILED);
        myintent.putExtra(ACTION_BLE_INIT_FAILED_REASON,reason);
        sendBroadcast(myintent);
    }

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                final String action = intent.getAction();
                if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                    final int stateAdapter = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
                    switch (stateAdapter) {
                        case BluetoothAdapter.STATE_ON:
                            sendBroadcast(new Intent(ACTION_BLE_INIT_COMPLETED));
                            break;
                        default:
                    }
                }
                if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)){
                    final int bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1);
                    if (bondState == BluetoothDevice.BOND_BONDED) {

                    }
                }
                if(BLE_Permissions.ACTION_BLE_PERMISSION_GRANTED.equals(action))
                {
                    PERMISSION_REQUEST_IN_COURSE = false;
                    InitService(ACTIVITY);
                }
                if(BLE_Permissions.ACTION_BLE_PERMISSION_DENIED.equals(action))
                {
                    PERMISSION_REQUEST_IN_COURSE = false;
                    sendBroadcastInitFailed("BLE Permission Denied");
                }

            }
            catch (Exception e) {
                Log.d("BLECB","EXCEPTION: "+ e);
                sendBroadcastInitFailed("Oops, exception caught during init");
            }
        }
    };

    BluetoothDevice GetBLEDevice(String add){
        return mBluetoothAdapter.getRemoteDevice(add);
    }


    Boolean IsPhy2MSupported() {return mBluetoothAdapter.isLe2MPhySupported();}


    void InitService(Activity activity){
        try {
            ACTIVITY = activity;
            if(PERMISSION_REQUEST_IN_COURSE) return;
            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager != null) {
                mBluetoothAdapter = bluetoothManager.getAdapter();
                if (!mBluetoothAdapter.isEnabled()){
                    Log.d("BLECB","BLUETOOTH not enabled; sending intent ...");
                    Intent intentBtEnable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    activity.startActivityForResult(intentBtEnable, 1);
                    return;
                } else {
                    bleScanner = new BLE_Scanner(ACTIVITY,mBluetoothAdapter);
                    sendBroadcast(new Intent(ACTION_BLE_INIT_COMPLETED));
                    Log.d("BLECB","BLE CONTEXT INITIALIZED.");
                }
            }
            else {
                Log.d("BLECB","Unable to initialize the BluetoothManager");
                sendBroadcastInitFailed("Unable to initialize the BluetoothManager");
            }
        }
        catch (Exception e) {
            Log.d("BLECB","EXCEPTION:" + e);
            sendBroadcastInitFailed("Oops, exception caught during init");
        }
    }

    boolean CheckAddressValid(String address){
        if (mBluetoothAdapter == null) return false;
        return BluetoothAdapter.checkBluetoothAddress(address);
    }



    Boolean StartScan(){
        if(bleScanner!=null){
            return bleScanner.StartScan();
        }
        return false;
    }

    void StopScan(){
        if(bleScanner==null) Log.d("BLECB","cannot stop scanner blescanner null");
        if(bleScanner!=null){
            bleScanner.StopScan();
            Log.d("BLECB","BLE Scan stopped.");
        }
    }


    private class BLE_Scanner {
        public Activity ACTIVITY = null;
        private BluetoothLeScanner bleScanner = null;
        private BluetoothAdapter mBluetoothAdapter = null;
        private String [] FILTER_ARRAY = null;

        public BLE_Scanner(Activity activity, BluetoothAdapter adapter){
            ACTIVITY = activity;
            mBluetoothAdapter = adapter;
        }

        public void ApplyFilterArray(String [] filters)
        {
            FILTER_ARRAY = filters;
        }

        public void RemoveFilterArray()
        {
            FILTER_ARRAY = null;
        }


        private byte[] reverse(byte[] array) {
            if (array == null) {
                return array;
            }
            int i = 0;
            int j = array.length - 1;
            byte tmp;
            while (j > i) {
                tmp = array[j];
                array[j] = array[i];
                array[i] = tmp;
                j--;
                i++;
            }
            return array;
        }

        private final char[] hexArray = "0123456789ABCDEF".toCharArray();
        public  String bytesToHex(byte[] bytes) {
            char[] hexChars = new char[bytes.length * 2];
            for ( int j = 0; j < bytes.length; j++ ) {
                int v = bytes[j] & 0xFF;
                hexChars[j * 2] = hexArray[v >>> 4];
                hexChars[j * 2 + 1] = hexArray[v & 0x0F];
            }
            return new String(hexChars);
        }

        private String [] ParseScanRecord(byte [] buffer)
        {
            byte type;
            int length;
            String [] retarray = new String[]{"UNNAMED","",""};
            int offset = 0;
            try {
                while (offset < buffer.length && buffer[offset]!=0x00) {
                    length = ((int) buffer[offset++])-1;
                    type = buffer[offset++];
                    byte[] bytevalue = Arrays.copyOfRange(buffer, offset, offset + length);
                    offset += length;

                    switch (type) {
                        case 0x07:
                            retarray[1] = bytesToHex(reverse(bytevalue)).replaceFirst("([0-9a-fA-F]{8})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]{4})([0-9a-fA-F]+)", "$1-$2-$3-$4-$5");
                            break;
                        case 0x08:
                        case 0x09:
                            retarray[0] = new String(bytevalue);
                            break;
                        case (byte) 0xFF:
                            retarray[2] = bytesToHex(bytevalue);
                            break;
                    }
                }
            }catch(Exception e){
                Log.d("BLECB","EXCEPTION:" + e);
            }
            return retarray;
        }


        private ScanCallback scancb = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                super.onScanResult(callbackType, result);
                ScanRecord sr = result.getScanRecord();
                if(sr==null) return;
                String [] parseScanRecord = ParseScanRecord(sr.getBytes());
                if(FILTER_ARRAY!=null)
                    if(FILTER_ARRAY.length>0){
                        for(String filter : FILTER_ARRAY){
                            String value = filter.substring(1);
                            if(filter.charAt(0)=='0'){
                                if(!parseScanRecord[0].equals(value)) return;
                            }
                            if(filter.charAt(0)=='1'){
                                if(!parseScanRecord[1].equals(value)) return;
                            }
                            if(filter.charAt(0)=='2'){
                                if(!result.getDevice().getAddress().equals(value)) return;
                            }
                        }
                    }
                String [] scanResultArray = new String[]{parseScanRecord[0], result.getDevice().getAddress(),"Service: <" + parseScanRecord[1] + ">", "Manuf.: <" + parseScanRecord[2] +">", String.valueOf(result.getRssi())};
                final Intent intent = new Intent(BLE_Service.ACTION_BLE_NEW_SCAN_RESULT);
                intent.putExtra(ACTION_BLE_SCAN_STRING_ARRAY, scanResultArray);
                ACTIVITY.sendBroadcast(intent);
            }
            @Override
            public void onScanFailed (int errorCode){
                if(errorCode != 1) Log.d("BLECB","SCAN NOT STARTED: ERR " + errorCode);
            }
        };

        public boolean StartScan(){
            if(mBluetoothAdapter==null)
                return false;
            if (bleScanner == null) {
                if (mBluetoothAdapter.isEnabled()) {
                    bleScanner = mBluetoothAdapter.getBluetoothLeScanner();
                    bleScanner.startScan(null, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scancb);
                    return true;
                }
            } else {
                bleScanner.startScan(null, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scancb);
                return true;
            }
            return false;
        }

        public void StopScan() {
            try {
                bleScanner.stopScan(scancb);
            }
            catch (Exception e) {
                Log.d("BLECB","EXCEPTION:" + e);
            }
        }
    }

}