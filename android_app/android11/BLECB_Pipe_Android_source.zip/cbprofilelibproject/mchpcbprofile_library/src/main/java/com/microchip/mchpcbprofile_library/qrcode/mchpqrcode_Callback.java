package com.microchip.mchpcbprofile_library.qrcode.qrcode;

public interface mchpqrcode_Callback {
    public void QRCOdeString(String content);
}
