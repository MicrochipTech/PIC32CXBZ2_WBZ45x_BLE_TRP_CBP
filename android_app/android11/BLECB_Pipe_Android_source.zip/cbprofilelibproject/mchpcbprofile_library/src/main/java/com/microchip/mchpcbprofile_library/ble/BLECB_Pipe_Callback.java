package com.microchip.mchpcbprofile_library.ble;

public interface BLECB_Pipe_Callback {
    public void ReceivedBytes(byte [] bytes);
    public void ConnectionStatus(boolean status,String comment);
}
