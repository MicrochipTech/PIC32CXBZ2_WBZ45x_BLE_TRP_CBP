package com.microchip.mchpcbprofile_library.ble;

import static com.microchip.mchpcbprofile_library.ble.BLE_Service.ACTION_BLE_SCAN_STRING_ARRAY;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Timer;
import java.util.concurrent.BlockingQueue;

public class BLECB_Pipe {
    private Boolean STATUS_INITIALIZED = false;
    private String BLUETOOTH_MAC_ADDRESS = "";
    private Activity ActivityContext = null;
    private BLE_Service mBluetoothLeService;
    private ServiceConnection mServiceConnection = null;
    private Timer ConnectionTimeoutTimer = null;
    private static DecimalFormat df2 = new DecimalFormat("#.##");
    BluetoothSocket socket;
    OutputStream OUT;
    InputStream IN;
    private BLECB_Pipe_Callback GLOBALCALLBACK = null;
    private BlockingQueue<String> MESSAGES_RECEIVEQUEUE;


    public BLECB_Pipe(Activity context){
        ActivityContext = context;
    }

    public void init(){
        Intent gattServiceIntent = new Intent(ActivityContext, BLE_Service.class);
        mServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder service) {
                mBluetoothLeService = ((BLE_Service.LocalBinder) service).getService();
                mBluetoothLeService.InitService(ActivityContext);
            }
            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                mBluetoothLeService = null;
            }
        };
        boolean mBound = ActivityContext.bindService(gattServiceIntent, mServiceConnection, Context.BIND_AUTO_CREATE);
        if(!mBound){
            Log.d("BLECB","Service cannot be bound.");
            return;
        }
        HandlerThread handlerThread = new HandlerThread("ht");
        handlerThread.start();
        Looper looper = handlerThread.getLooper();
        Handler handler = new Handler(looper);
        ActivityContext.registerReceiver(BLEObjectBcastReceiver, constructBLEObjectIntentFilter(), null, handler);
    }

    public void deinit(){
        ActivityContext.unregisterReceiver(BLEObjectBcastReceiver);
        ActivityContext.unbindService(mServiceConnection);
    }

    private final BroadcastReceiver BLEObjectBcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BLE_Service.ACTION_BLE_INIT_COMPLETED.equals(action)) {
                STATUS_INITIALIZED = true;
                if(mBluetoothLeService.StartScan()) Log.d("BLECB","BLE Scan started ...");
            }
            if (BLE_Service.ACTION_BLE_INIT_FAILED.equals(action)) {
                String s = intent.getStringExtra(BLE_Service.ACTION_BLE_INIT_FAILED_REASON);
                STATUS_INITIALIZED = false;
            }
            if (BLE_Service.ACTION_BLE_NEW_SCAN_RESULT.equals(action)) {
                String [] scans = intent.getStringArrayExtra(ACTION_BLE_SCAN_STRING_ARRAY);
                String s = "";
                for(String scan : scans) s += scan + " ";
                Log.d("BLECB","SCAN: " + s);
            }

        }
    };

    private IntentFilter constructBLEObjectIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BLE_Service.ACTION_BLE_INIT_COMPLETED);
        intentFilter.addAction(BLE_Service.ACTION_BLE_INIT_FAILED);
        intentFilter.addAction(BLE_Service.ACTION_BLE_NEW_SCAN_RESULT);
        return intentFilter;
    }

    private class inputstream_task implements Runnable{
        byte [] received = new byte[1024];

        public inputstream_task(){

        }

        @Override
        public void run() {
            while(socket.isConnected()){
                try {


                    int read=0;
                    int totallyread=0;
                    while(totallyread!=2){
                        read = IN.read(received,0,2-totallyread);
                        if(read==-1) throw new Exception("SOCKET CLOSED");
                        totallyread += read;
                    }
                    int l = (received[1] & 0xFF) << 8 | (received[0] & 0xFF);
                    totallyread=0;
                    while(totallyread!=l){
                        read = IN.read(received,totallyread,l-totallyread);
                        if(read==-1) throw new Exception("SOCKET CLOSED");
                        totallyread += read;
                    }
                    Log.d("BLECB","RECEIVED: " + new String(Arrays.copyOf(received,l)));
                    String serialized =  new String(Arrays.copyOf(received,l));
                    if(GLOBALCALLBACK!=null) {
                        ActivityContext.runOnUiThread(()->{
                            GLOBALCALLBACK.ReceivedBytes(Arrays.copyOf(received, l));
                        });
                    }
                    //}
                }catch(Exception e){
                    if(!e.getLocalizedMessage().equals("SOCKET CLOSED")) Log.d("BLECB","EXCEPTION: " + e);
                    if(socket.isConnected()) try{socket.close();}catch(Exception ex){Log.d("BLECB","EXCEPTION: " + ex);}
                    if(GLOBALCALLBACK!=null) {
                        ActivityContext.runOnUiThread(()-> {
                            GLOBALCALLBACK.ConnectionStatus(false, "DISCONNECTED");
                        });
                    }
                }
            }
            Log.d("BLECB","Socket Disconnected: RECEIVE THREAD ENDED");
            if(GLOBALCALLBACK!=null) {
                ActivityContext.runOnUiThread(()-> {
                    GLOBALCALLBACK.ConnectionStatus(false, "DISCONNECTED");
                    if(mBluetoothLeService.StartScan()) Log.d("BLECB","BLE Scan started ...");
                });
            }
        }
    }



    private class connection_task extends Thread{
        String targetadd;

        public connection_task(String address){
            targetadd   = address;
        }

        @Override
        public void run() {
            BluetoothDevice device = mBluetoothLeService.GetBLEDevice(targetadd);
            if(device==null){
                Log.d("BLECB","cannot get device");
                ActivityContext.runOnUiThread(()->{GLOBALCALLBACK.ConnectionStatus(false,"CANNOT CONNECT");});
                return;
            }
            try{

                socket = device.createInsecureL2capChannel(0x0081);
                if(socket==null) {
                    Log.d("BLECB","invalid device");
                    if(GLOBALCALLBACK!=null)
                    ActivityContext.runOnUiThread(()->{GLOBALCALLBACK.ConnectionStatus(false,"CANNOT CONNECT");});
                    return;
                }
                socket.connect();
                /*if(mBluetoothLeService.IsPhy2MSupported()){
                    debugLOG.getInstance().printAlways("PHY2 SUPPORTED !!!");
                }*/
                OUT = socket.getOutputStream();
                IN = socket.getInputStream();
                Log.d("BLECB"," MAX TX PACKET : " + socket.getMaxTransmitPacketSize());
                ActivityContext.runOnUiThread(()-> new Thread(new inputstream_task()).start());
                Log.d("BLECB","CONNECTION ESTABLISHED ON L2CAP FOR DEVICE " + targetadd);
                ActivityContext.runOnUiThread(()->{GLOBALCALLBACK.ConnectionStatus(true,"CONNECTED");});
            }catch(Exception e){
                Log.d("BLECB","EXCEPTION: " + e);
                ActivityContext.runOnUiThread(()->{GLOBALCALLBACK.ConnectionStatus(false,"CANNOT CONNECT");});
                if(mBluetoothLeService.StartScan()) Log.d("BLECB","BLE Scan started ...");
                return;
            }
        }
    }

    public void Disconnect(){
        try {
            socket.close();
        }catch(Exception e) {
            Log.d("BLECB","EXCEPTION: " + e);
        }
    }

    public void Connect(String add, BLECB_Pipe_Callback callback){
        if(mBluetoothLeService==null || !STATUS_INITIALIZED) return;
        mBluetoothLeService.StopScan();
        GLOBALCALLBACK = callback;
        connection_task conn = new connection_task(add);
        conn.start();
    }

    class Message {
        private int leng = 0;
        private byte [] m = null;
        public Message(String msg){
            leng = msg.length();
            m = msg.getBytes();
        }
        public Message(byte [] msg){
            leng = msg.length;
            m = msg;
        }
        public byte [] getBytes(){
            ByteArrayOutputStream ba = new ByteArrayOutputStream();
            try{
                ba.write((byte)leng);
                ba.write((byte)(leng >>> 8));
                ba.write(m);
                return ba.toByteArray();
            }catch (Exception e){Log.d("BLECB","EXCEPTION: " + e);return null;}
        }
    }


    private class send_task extends Thread{
        byte [] bytes;
        Runnable send_completed;
        public send_task(byte [] bb, Runnable completed){
            bytes = bb;
            send_completed = completed;
        }
        @Override
        public void run() {
            super.run();
            try {
                OUT.write(bytes);
                if(send_completed!=null) {
                    ActivityContext.runOnUiThread(send_completed);
                }
            }catch (Exception e){
                Log.d("BLECB","EXCEPTION: " +e);
            }
        }
    }

    private class send_task_file extends Thread{
        byte [] bytes;
        Runnable send_completed;
        public send_task_file(byte [] bb, Runnable completed){
            bytes = bb;
            send_completed = completed;
        }
        @Override
        public void run() {
            super.run();
            try {



                Message startmsg = new Message("\nSTART\n".getBytes());
                OUT.write(startmsg.getBytes());
                //Message onekb = new Message(new byte[1000]);
                //for(int i=0; i<10; i++) OUT.write(onekb.getBytes());




                ByteArrayInputStream ba = new ByteArrayInputStream(bytes);
                byte [] buffer = new byte[2000];
                int read=0;
                int readsofar=0;
                while(readsofar< bytes.length){
                    read = ba.read(buffer,0,1000);
                    //Log.d("BLECB","Read " + read + ", so far " + readsofar);
                    Message onekb = new Message(Arrays.copyOf(buffer,read));
                    OUT.write(onekb.getBytes());
                    readsofar += read;
                }

                //OUT.write(bytes);
                startmsg = new Message("\nSTOP \n".getBytes());
                OUT.write(startmsg.getBytes());

                if(send_completed!=null) {
                    ActivityContext.runOnUiThread(send_completed);
                }
            }catch (Exception e){
                Log.d("BLECB","EXCEPTION: " +e);
            }
        }
    }

    public void Send(byte [] bytes, Runnable sendcompleted) {
        Message msg = new Message(bytes);
        new send_task(msg.getBytes(),sendcompleted).start();
    }

    public void SendFile(byte [] bytes, Runnable sendcompleted) {
        //Message msg = new Message(bytes);
        new send_task_file(bytes,sendcompleted).start();
    }

}
