package com.microchip.mchpcbprofile_library.ble;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

public class BLE_Permissions extends Activity {
    private static final int REQ_CODE_ACCESS_LOC1 = 3;
    private static final int REQ_CODE_ACCESS_LOC2 = 4;
    public final static String ACTION_BLE_PERMISSION_GRANTED = "com.microchip.ACTION_BLE_PERMISSION_GRANTED";
    public final static String ACTION_BLE_PERMISSION_DENIED  = "com.microchip.ACTION_BLE_PERMISSION_DENIED";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_CODE_ACCESS_LOC1);
        }
    }

    private void showLocationPermissionDialog(final Runnable callback) {
        AlertDialog dialog;
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(this);
        dialog = builder.create();
        dialog.dismiss();
        builder.setTitle("Location Permission Required");
        builder.setMessage("App cannot scan");
        builder.setPositiveButton("continue", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                callback.run();
            }
        });
        builder.setNegativeButton(null, null);
        dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQ_CODE_ACCESS_LOC1:
                if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                    showLocationPermissionDialog(new Runnable() {
                        @TargetApi(Build.VERSION_CODES.M)
                        @Override
                        public void run() {
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_CODE_ACCESS_LOC2);
                        }
                    });
                }
            case REQ_CODE_ACCESS_LOC2:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //simpleMAP_debug.getInstance().print("Coarse location permission granted");
                    sendBroadcast(new Intent(ACTION_BLE_PERMISSION_GRANTED));
                    finish();
                }else{
                    //simpleMAP_debug.getInstance().printAlways("Coarse location permission denied");
                    sendBroadcast(new Intent(ACTION_BLE_PERMISSION_DENIED));
                    finish();
                }
        }
    }

    @Override
    public void onStop(){
        super.onStop();
    }
}