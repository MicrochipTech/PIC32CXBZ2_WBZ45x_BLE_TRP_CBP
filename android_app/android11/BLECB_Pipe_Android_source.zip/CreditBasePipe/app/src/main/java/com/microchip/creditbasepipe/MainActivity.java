package com.microchip.creditbasepipe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import com.microchip.mchpcbprofile_library.qrcode.mchpqrcode;
import com.microchip.mchpcbprofile_library.ble.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends Activity {
    Activity ACTIVITY = this;
    BLECB_Pipe blecbPipe = new BLECB_Pipe(this);
    private static final String targetmac = "00:11:67:93:93:93";
    private static final String targetmsg = "Message from Android";
    private static final String targetfilesize = "5";
    LinearLayout settingsview = null;
    LinearLayout mainview = null;
    LinearLayout connectedview = null;
    ProgressBar progressBar = null;
    ImageButton connectbutton = null;
    Switch msgfileswitch = null;
    TextView receivepool = null;
    ScrollingMovementMethod receivepoolscroll = null;
    private static SharedPreferences PREFERENCES;
    private static final String APPSTORAGE = "CBPipe";
    private static final String APPSTORED_BLEMAC = "CBPipe_blemac";
    private static final String APPSTORED_MSG = "CBPipe_msg";
    private static final String APPSTORED_FILESIZE = "CBPipe_filesize";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // --- ACTIVITY IN FULL SCREEN WITH NO TITLE
        Window window = ACTIVITY.getWindow();
        View decorView = ACTIVITY.getWindow().getDecorView();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        WindowInsetsControllerCompat controllerCompat = new WindowInsetsControllerCompat(window, decorView);
        controllerCompat.hide(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.navigationBars());
        controllerCompat.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

        setContentView(R.layout.activity_main);
        msgfileswitch = (Switch)findViewById(R.id.switch1);
        msgfileswitch.setOnClickListener(v -> {
            if(msgfileswitch.isChecked()) {
                msgfileswitch.setText("FILE");
            }else{
                msgfileswitch.setText("MESSAGE");
            }
        });
        settingsview = (LinearLayout)findViewById(R.id.settingslayout);
        connectedview = (LinearLayout)findViewById(R.id.connectedlayout);
        progressBar = (ProgressBar)findViewById(R.id.indeterminateBarProgress);
        receivepool = (TextView)findViewById(R.id.receivepool);
        receivepoolscroll = new ScrollingMovementMethod();
        receivepool.setMovementMethod(receivepoolscroll);
        connectbutton = (ImageButton)findViewById(R.id.connectbutton);
        progressBar.setVisibility(View.GONE);
        settingsview.animate().scaleX(0.0F).scaleY(0.0F).setDuration(10).start();
        settingsview.setVisibility(View.INVISIBLE);
        connectedview.animate().scaleX(0.0F).scaleY(0.0F).setDuration(10).start();
        connectedview.setVisibility(View.INVISIBLE);
        mainview = (LinearLayout)findViewById(R.id.mainlayout);
        blecbPipe.init();
        PREFERENCES = ACTIVITY.getSharedPreferences(APPSTORAGE, Context.MODE_PRIVATE);
    }

    public void APPStorage_Put(String key, String value){
        SharedPreferences.Editor editor = PREFERENCES.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public String APPStorage_Get(String key, String defaultvalue){
        return PREFERENCES.getString(key,defaultvalue);
    }

    public void settings_retrieve(){
        ((EditText)findViewById(R.id.macedit)).setText(APPStorage_Get(APPSTORED_BLEMAC,targetmac));
        ((EditText)findViewById(R.id.msgedit)).setText(APPStorage_Get(APPSTORED_MSG,targetmsg));
        int filesize = Integer.parseInt(APPStorage_Get(APPSTORED_FILESIZE,targetfilesize));
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radiogroup);
        int rtocheck = R.id.radio_5k;
        switch (filesize){
            case 5:     rtocheck = R.id.radio_5k;break;
            case 10:    rtocheck = R.id.radio_10k;break;
            case 50:    rtocheck = R.id.radio_50k;break;
            case 100:   rtocheck = R.id.radio_100k;break;
        }
        radioGroup.check(rtocheck);
    }

    public void settings_store(View v){
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radiogroup);
        String filesize = "5";
        switch (radioGroup.getCheckedRadioButtonId()){
            case R.id.radio_5k: filesize = "5"; break;
            case R.id.radio_10k: filesize = "10"; break;
            case R.id.radio_50k: filesize = "50"; break;
            case R.id.radio_100k: filesize = "100"; break;
        }
        APPStorage_Put(APPSTORED_FILESIZE,filesize);
        APPStorage_Put(APPSTORED_MSG,((EditText)findViewById(R.id.msgedit)).getText().toString());
        String mactostore = ((EditText)findViewById(R.id.macedit)).getText().toString();
        Log.d("BLECB",mactostore);
        if(!validate(mactostore)) {
            ((EditText)findViewById(R.id.macedit)).setTextColor(Color.RED);
            return;
        }
        APPStorage_Put(APPSTORED_BLEMAC,mactostore);
        settingsview.animate().scaleX(0.0F).scaleY(0.0F).setDuration(200).withEndAction(()->{
            runOnUiThread(()->{

                InputMethodManager imm = (InputMethodManager) ACTIVITY.getSystemService(Activity.INPUT_METHOD_SERVICE);
                View view = ACTIVITY.getCurrentFocus();
                if (view == null) {
                    view = new View(ACTIVITY);
                }
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                view.clearFocus();
                settingsview.setVisibility(View.INVISIBLE);
            });
        }).start();
    }

    public void settings_open(View v){
        settings_retrieve();
        settingsview.setVisibility(View.VISIBLE);
        settingsview.animate().scaleX(1.0F).scaleY(1.0F).setDuration(200).start();
    }

    public void settings_close(View v){
        settingsview.animate().scaleX(0.0F).scaleY(0.0F).setDuration(200).withEndAction(()->{
            runOnUiThread(()->{

                InputMethodManager imm = (InputMethodManager) ACTIVITY.getSystemService(Activity.INPUT_METHOD_SERVICE);
                View view = ACTIVITY.getCurrentFocus();
                if (view == null) {
                     view = new View(ACTIVITY);
                }
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                view.clearFocus();
                settingsview.setVisibility(View.INVISIBLE);
            });
        }).start();

    }

    public void connect_click(View v){
         if(((TextView)findViewById(R.id.connectbuttonlabel)).getText().equals("CONNECT")) {
            progressBar.setVisibility(View.VISIBLE);
            ((ImageButton) v).setEnabled(false);
             receivepool.setText("");
            blecbPipe.Connect(APPStorage_Get(APPSTORED_BLEMAC,targetmac), new BLECB_Pipe_Callback() {
                @Override
                public void ReceivedBytes(byte[] bytes) {
                    ACTIVITY.runOnUiThread(()->{
                        receivepool.setText(receivepool.getText() + new String(bytes));
                    });
                }

                @Override
                public void ConnectionStatus(boolean status, String comment) {
                    if (status) {
                        progressBar.setVisibility(View.GONE);
                        connectedview.setVisibility(View.VISIBLE);
                        connectedview.animate().scaleX(1.0F).scaleY(1.0F).setDuration(200).start();
                        ((TextView) findViewById(R.id.connectbuttonlabel)).setText("DISCONNECT");
                        connectbutton.setEnabled(true);
                        msgfileswitch.setChecked(false);
                        msgfileswitch.setText("MESSAGE");
                    } else {
                        progressBar.setVisibility(View.GONE);
                        connectedview.animate().scaleX(0.0F).scaleY(0.0F).setDuration(200).withEndAction(()->{
                            runOnUiThread(()-> {
                                connectedview.setVisibility(View.INVISIBLE);
                            });
                        });
                        ((TextView) findViewById(R.id.connectbuttonlabel)).setText("CONNECT");
                        connectbutton.setEnabled(true);
                    }
                }
            });
        }else{
            blecbPipe.Disconnect();
        }
    }

    public void connected_send(View v){
        if(msgfileswitch.isChecked()){
            int filesize = Integer.parseInt(APPStorage_Get(APPSTORED_FILESIZE,targetfilesize));
            blecbPipe.SendFile(new byte[filesize * 1000],null);
        }else {
            blecbPipe.Send(("\n" + APPStorage_Get(APPSTORED_MSG, targetmsg)).getBytes(), null);
        }
    }

    public void getmacfromQRCode(View v){
        mchpqrcode qrcodescanner = new mchpqrcode(ACTIVITY);
        qrcodescanner.GetQRCode(dataread->{
            if(dataread==null) return;
            Log.d("BLECB",dataread);
            if(validate(dataread)){
                ((EditText)findViewById(R.id.macedit)).setText(dataread);
            }else{
                ((EditText)findViewById(R.id.macedit)).setText("<INVALID>");
            }
        });
    }

    public boolean validate(String mac) {
        String regex = "^([0-9A-Fa-f]{2}[:-])"
                + "{5}([0-9A-Fa-f]{2})|"
                + "([0-9a-fA-F]{4}\\."
                + "[0-9a-fA-F]{4}\\."
                + "[0-9a-fA-F]{4})$";
        //"^([a-fA-F0-9]{2}[:-]){5}[a-fA-F0-9]{2}$"
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(mac);
        return m.matches();
    }
}